# **Saving SuperStore**

**Part 1: Profits & losses**

First, we'll try to identify the important centers of profit and loss for the superstore.

**Among the pairs of dimensions (e.g., subcategory + region, or shipping mode + product ID) which are the two biggest profit centers and two biggest loss-makers? Justify your conclusion with a visualization.**

As found in the chart titled, "_Most Profitable Sub-category By Region_", the two biggest profit centers regions are the West and the East regions for phones and copiers, and the two biggest loss maker regions are Central and East, binders and tables.
    
**Which products should the superstore stop selling? Justify your conclusion with a visualization.**

As seen in the table, "_Product ID/Profit_", TEC-MA-10000418 and TEC-MA-10004125, as well as the OFF-BI-10004995. These three items make up the most of the profit losses.

**Which product subcategories should the store focus on and which should they stop selling? Choose 3 of each.**

As seen in the chart titled, "_Profit Leaders_", the store should focus on the Copiers, Chairs, and Access as these three subcategories have the highest profits.
As seen in the companion chart, "_Profit Loss Leaders_" the subcategories Tables, Bookcases, and Supplies that have very low profits and the sale of these items should discontinue.

**Part 2: Advertising**

The superstore wants to know if advertising would be worth it. Advertising works over time and geography, and your average profit per unit sold should be high enough to justify it.

Identify the 3 best combinations of states and month of the year to advertise in. Make a visualization of the average profit for each month of the year for those 3 states and argue how much you would be willing to pay in advertising for those states in those months.

Based on the chart, "_States and Months_", the three states and months to advertise, based on the average profit of each, would be Indiana in October, Vermont in November, and Rhode Island in December.

The amount to spend would be based upon 20% of the profit for each item. This would be based on the total count for each state and month, but would be approximately as little as $50/item in Rhode Island and as much as $128/item in Indiana.


**Part 3: Returned items**

To determine which products have the highest return rate, it can be seen in the chart, "*Most Returned Item*s" that the Acco Glide Clips, Avery 500, and the Bush Saratoga Collection 5-Shelf Bookcase, Hanover Cherry, *Special Order, all have a 100% return rate.
The chart called "_Most Returned Customer_" shows that the following customer have returned 100% of their products: Hilary Holden, Roland Murray, and Sandra Glassco.

An examination of the "_Average Returns By State_" shows that states such as Arkansas, Connecticut, District of Columbia, Iowa, Kansas,Main, and Nevada have a zero return rate, suggesting that continuing to do business in these states should continue.

However, in the same chart, Arizona, Colorado, Florida, and Illinois have substantial returns and are not profitable, and decisions should be made whether or not to continue doing business in these states.

The link to the charts can be found at: [[Tableau](https://public.tableau.com/views/Book1_17122413865180/Avg_returns_by_state?:language=en-US&publish=yes&:sid=&:display_count=n&:origin=viz_share_link)]