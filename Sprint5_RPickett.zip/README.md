# **Returns of SuperStore**

**Part 1: Analysis Summary**


**How should returns be measured?**

Returns should be done by the return rate as it provides a more consistent metric than sales. The concern is returns, and having a consistent metric gives us a starting point. The total cost is variable as it depends on the product.

   
**What are the key root causes of returns?**

The returns appear to be as a result of supply chain issues with a vendor that provided defective parts, thereby causing faults. The vendor has filed for bankruptcy protection.

**Describe actions that can be taken after using the Dashboard to identify the root causes**

Now that the problem has been identified the dashboard can auto-update with new information as it arrives, and should show a decrease in the return rate over the next few months.


The link to the charts can be found at: [[Tableau](https://public.tableau.com/views/ReturnsSprint5/ReturnsExamination_notes?:language=en-US&publish=yes&:sid=&:display_count=n&:origin=viz_share_link]